<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <title>Document</title>
    <style>
        table{
            width: 50%;
            border-collapse: collapse;
            border: 2px solid blue;
            margin: auto;
        }
        td,th{
            border: 1px solid blue;
            padding: 10px;
            text-align: center;
        }
        input[type=text]{
            padding:10px;
           
        }
    </style>
</head>
<body>
    <h1 style="text-align: center; text-transform: uppercase;">edit members</h1>

    <form  method="post" action="update">
        <table>
            <tr>
                <td>name</td>
                <td><input type="text" name="name" value="<?php echo $result->full_name; ?>"></td>
            </tr>
            <tr>
                <td>email</td>
                <td><input type="text" name="email" value="<?php echo $result->email; ?>"></td>
            </tr>
            <tr>
                <td>mobile</td>
                <td><input type="text" name="mobile" value="<?php echo $result->mobile; ?>"></td>
            </tr>
            <tr>
            <td colspan="2">
                <input type="hidden" name="cid" value="<?php echo $result->sr_no; ?>"><br>
                <input class="btn btn-primary" type="submit" name="submit"></td></tr>
        </table>
    </form>

</body>
</html>