<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <title>Document</title>
    <style>
        table{
            width: 80%;
            border-collapse: collapse;
            border: 2px solid blue;
            margin: auto;
        }
        td,th{
            border: 1px solid blue;
            padding: 10px;
            text-align: center;
        }
    input[type=text]{
        padding:10px;
    }
    input[type=submit]{
        padding:10px;
        background-color: indianred;
    }
    </style>
</head>
<body>
    <h1 style="text-align: center; text-transform: uppercase;">all members</h1>
     <a href=""></a>
     <a style="margin-left: 5vw;margin-bottom:5vh;font-weight:600 " href="add" class="btn btn-warning">add member</a>
   
     <?php 
		if (isset($_SESSION['dataResult'])) {
	?>
		
        <h1 style="text-align:center;color: <?php echo $_SESSION['dataResult']['class'] ?>"><?php echo $_SESSION['dataResult']['message']; ?></h1>
	<?php
		unset($_SESSION['dataResult']);
		}
	?>
     <table>
         <tr>
             <td>sr.no</td>
             <td>name</td>
             <td>mobile</td>
             <td>email</td>
             <td>action</td>
         </tr>
  <?php
    foreach ($result as $key =>$value){
        ?><tr>
            <td><?php echo ++$key ?></td>
            <td><?php echo $value->full_name ?></td>
            <td><?php echo $value->mobile ?></td>
            <td><?php echo $value->email ?></td>
            <td>
                <a class="btn btn-success" href="edit?id=<?php echo $value->sr_no; ?>">edit</a>
                <a class="btn btn-danger" href="delete?id=<?php echo $value->sr_no; ?>">delete</a>
            </td>
        </tr><?php
    }
  ?>

     </table>
    
    
</body>
</html>