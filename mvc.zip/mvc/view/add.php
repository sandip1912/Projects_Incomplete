<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <title>Document</title>
    <style>
        table{
            width: 50%;
            border-collapse: collapse;
            border: 2px solid blue;
            margin: auto;
        }
        td,th{
            border: 1px solid blue;
            padding: 10px;
            text-align: center;
        }
    input[type=text]{
        padding:10px;
    }
    input[type=submit]{
        padding:10px;
        color: white;
        font-weight: 600;
        background-color: teal;
    }
    </style>
</head>
<body>
    <h1 style="text-align: center; text-transform: uppercase;">add member page</h1>
    <?php 
    if(isset($message)){
        ?>
        <h1 style="text-align:center;color: <?php echo $message['color'] ?>"><?php echo $message['message']; ?></h1>
        </div>
        <?php

    } ?>
    <form action="" method="post">
    <table>
        <tr>
            <td >name</td>
            <td><input type="text" name="name" id=""></td>
        </tr>
        <tr>
            <td>email</td>
            <td><input type="text" name="email" id=""></td>
        </tr>
        <tr>
            <td>mobile</td>
            <td><input type="text" name="mobile" id=""></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit" name="submit" id=""></td>
        </tr>
    </table>
    </form>

    <a style="margin-left: 45vw;margin-top:5vh;" href="http://localhost/php/practice/sandeep/mvc" class="btn btn-warning">Back To Home</a>
    
</body>
</html>