<?php

    // echo "hello  crude model";
    class CrudModel{
    private $serverName = "localhost";
	private $userName = "root";
	private $password = "";
	private $databaseName = "crud_practice";
	public $conn;
	public $query;
	public $result;
	public $response;


	public function __construct() {

		$this->dbConnect();
	}
	

	public function dbConnect() {

		$this->conn = mysqli_connect($this->serverName, $this->userName, $this->password, $this->databaseName);

		return $this->conn;

	}


	public function getData($table) {
        $this->query = "SELECT * FROM $table";
        $this->result = mysqli_query($this->conn,$this->query);
        while ($this->response[] = mysqli_fetch_object($this->result)) {}
		return array_filter($this->response);        
	}
    
    public function insertdata($table,$data){
		$arrayKey = array_keys($data);
		$colName = "`".implode("`,`", $arrayKey)."`";
		$values = "'".implode("','", $data)."'";
		$this->query = "INSERT INTO $table ($colName) VALUES ($values)";
		// $this->query = "INSERT INTO $table (`mobile`,`full_name`) VALUES ('$_POST[mobile]','$_POST[full_name]')";
		return $this->result = mysqli_query($this->conn, $this->query);
    }
	
    public function editdata($table,$data){
        $this->query = "SELECT * FROM $table WHERE sr_no=".$data;
		$this->result = mysqli_query($this->conn, $this->query);
		return $this->result = mysqli_fetch_object($this->result);
    }
    public function updateData($table, $data) {

		$this->query = "UPDATE $table SET `mobile`='".$data['mobile']."',`full_name`='".$data['name']."' WHERE sr_no=".$data['cid'];
		return $this->result = mysqli_query($this->conn, $this->query);
		
	}
    public function deleteData($table, $data) {

		$this->query = "DELETE FROM $table WHERE sr_no=".$data;
		return $this->result = mysqli_query($this->conn, $this->query);

	}

    }

?>
