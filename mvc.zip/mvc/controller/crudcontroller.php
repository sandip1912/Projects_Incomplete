<?php
session_start();
include_once "model/crudmodel.php";
class crudcontroller extends crudmodel{
    public function __construct(){
        parent::__construct();
        
        if(isset($_SERVER['PATH_INFO'])){
            switch($_SERVER['PATH_INFO']){

                case "/add":
                    if(isset($_POST['submit'])){
                        $data = array(
                            'mobile' =>$_POST['mobile'],
                            'full_name' =>$_POST['name'],
                            'email' =>$_POST['email'],
                        );
                        $result = $this->insertData('register1',$data);
                   
                    if($result){
                        $message = array("message" => "Inserted", "color" => "green");
                        
                    }else{
                    
                        $message = array("message" => "not Inserted", "color" => "red");

                    }
                    }
                    include_once 'view/add.php';

                    break;

                case "/edit":
                    if(isset($_GET['id'])){ 
                        
                        $result = $this->editdata('register1',$_GET['id']);
                    }
                    include_once 'view/edit.php';
                    break;
                 
                    case '/update':

                        if (isset($_POST['submit'])) {
                                       // print_r($_POST);
                            $result = $this->updateData('register1', $_POST);
                            if ($result) {
                                $_SESSION['dataResult'] = array(
                                "message" => "Data Updated", "class" => "green" );} 
                            else {
                            $_SESSION['dataResult'] = array(
                                            "message" => "Error", "class" => "red"
                                        );
                                    }


               
                                 header("Location: http://localhost/php/practice/sandeep/mvc");
                           }
                       break;

                       case '/delete':

                        if (isset($_GET['id'])) {
                    
                            $result = $this->deleteData('register1', $_GET['id']);
                    
                            if ($result) {
                                    $_SESSION['dataResult'] = array(
                                        "message" => "Data Deleted", "class" => "green" );}
                                 else {
                                 $_SESSION['dataResult'] = array(
                                        "message" => "Error", "class" => "red" );}
                            header("Location: http://localhost/php/practice/sandeep/mvc");
                        }    
                             
               
            }
        }else{
            $result = $this->getData('register1');
            include_once 'View/show.php';
        }
   
       
  
}
}

$object = new crudController;


?>